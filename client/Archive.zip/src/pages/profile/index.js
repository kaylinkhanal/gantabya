const Profile= ()=>{
    return (
        <div>
            test
            </div>
    )
}

export default Profile